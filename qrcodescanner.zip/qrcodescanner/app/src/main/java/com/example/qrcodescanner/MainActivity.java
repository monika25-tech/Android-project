package com.example.qrcodescanner;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.journeyapps.barcodescanner.BarcodeCallback;
import com.journeyapps.barcodescanner.BarcodeResult;
import com.journeyapps.barcodescanner.CompoundBarcodeView;
import com.google.zxing.ResultPoint;
import java.util.List; // Import the List class

public class MainActivity extends AppCompatActivity {

    private CompoundBarcodeView barcodeScannerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        barcodeScannerView = findViewById(R.id.barcode_scanner);
        Button btnScan = findViewById(R.id.btnScan);

        btnScan.setOnClickListener(v -> barcodeScannerView.decodeContinuous(callback));
    }

    private final BarcodeCallback callback = new BarcodeCallback() {
        @Override
        public void barcodeResult(BarcodeResult result) {
            Toast.makeText(MainActivity.this, "Scanned: " + result.getText(), Toast.LENGTH_LONG).show();
            // Handle the scanned result
        }

        @Override
        public void possibleResultPoints(List<ResultPoint> resultPoints) {
            // This method receives a List of ResultPoint objects
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        barcodeScannerView.resume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        barcodeScannerView.pause();
    }
}
