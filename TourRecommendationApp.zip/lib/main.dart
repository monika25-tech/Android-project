import 'package:flutter/material.dart';

void main() {
  runApp(TourRecommendationApp());
}

class TourRecommendationApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  // Sample data for tour recommendations
  final List<Tour> tours = [
    Tour(
      title: "Historical Monuments Tour",
      description: "Explore the historical landmarks in the city.",
      duration: "3 hours",
    ),
    Tour(
      title: "Nature and Wildlife Tour",
      description: "Experience the natural beauty and wildlife.",
      duration: "5 hours",
    ),
    Tour(
      title: "City Highlights Tour",
      description: "Discover the must-see attractions in the city.",
      duration: "4 hours",
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Tour Recommendations"),
      ),
      body: ListView.builder(
        itemCount: tours.length,
        itemBuilder: (context, index) {
          final tour = tours[index];
          return Card(
            child: ListTile(
              title: Text(tour.title),
              subtitle: Text(tour.description),
              trailing: Text(tour.duration),
            ),
          );
        },
      ),
    );
  }
}

class Tour {
  final String title;
  final String description;
  final String duration;

  Tour(
      {required this.title, required this.description, required this.duration});
}
