package com.example.pdfpicker;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class MainActivity extends AppCompatActivity {
    // Initialize variables
    Button btnSelect;
    TextView tvUri, tvPath;
    ActivityResultLauncher<Intent> resultLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Assign variables
        btnSelect = findViewById(R.id.btn_select);
        tvUri = findViewById(R.id.tv_uri);
        tvPath = findViewById(R.id.tv_path);

        // Initialize result launcher using lambda
        resultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    // Initialize result data
                    Intent data = result.getData();
                    if (data != null) {
                        // When data is not empty
                        // Get PDF URI
                        Uri sUri = data.getData();
                        // Set URI on text view
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                            tvUri.setText(Html.fromHtml("<big><b>PDF Uri</b></big><br>" + sUri, Html.FROM_HTML_MODE_LEGACY));
                            tvPath.setText(Html.fromHtml("<big><b>PDF Path</b></big><br>" + sUri.getPath(), Html.FROM_HTML_MODE_LEGACY));
                        } else {
                            tvUri.setText(Html.fromHtml("<big><b>PDF Uri</b></big><br>" + sUri));
                            tvPath.setText(Html.fromHtml("<big><b>PDF Path</b></big><br>" + sUri.getPath()));
                        }
                    }
                }
        );

        // Set click listener on button
        btnSelect.setOnClickListener(view -> {
            // Check condition
            if (ActivityCompat.checkSelfPermission(
                    MainActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                // When permission is not granted
                // Request permission
                ActivityCompat.requestPermissions(MainActivity.this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
            } else {
                // When permission is granted
                // Call method
                selectPDF();
            }
        });
    }

    private void selectPDF() {
        // Initialize intent
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        // Set type
        intent.setType("application/pdf");
        resultLauncher.launch(intent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // Check condition
        if (requestCode == 1 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            // When permission is granted
            // Call method
            selectPDF();
        } else {
            // When permission is denied
            // Display toast
            Toast.makeText(getApplicationContext(), "Permission Denied", Toast.LENGTH_SHORT).show();
        }
    }
}
