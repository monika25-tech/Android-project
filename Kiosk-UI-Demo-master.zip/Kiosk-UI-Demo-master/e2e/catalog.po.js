'use strict';

var CatalogPage = function () {
	this.categories = element.all(by.model(vm.categories));

};

module.exports = new CatalogPage();