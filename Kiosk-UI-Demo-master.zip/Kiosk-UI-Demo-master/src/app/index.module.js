(function() {
  'use strict';

  angular
    .module('kioskUi', ['ngAnimate', 'ngCookies', 'ngTouch', 'ngSanitize', 'restangular', 'ui.router', 'ui.bootstrap', 'firebase']);

})();
