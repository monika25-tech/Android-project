package com.example.hostelmanagementapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
