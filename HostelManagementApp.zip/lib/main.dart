import 'package:flutter/material.dart';

void main() {
  runApp(HostelManagementApp());
}

class HostelManagementApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final List<Room> rooms = [
    Room(number: '101', status: 'Occupied', occupant: 'John Doe'),
    Room(number: '102', status: 'Available', occupant: ''),
    Room(number: '103', status: 'Occupied', occupant: 'Jane Smith'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Hostel Management'),
      ),
      body: ListView.builder(
        itemCount: rooms.length,
        itemBuilder: (context, index) {
          final room = rooms[index];
          return Card(
            child: ListTile(
              title: Text('Room ${room.number}'),
              subtitle:
                  Text('Status: ${room.status}\nOccupant: ${room.occupant}'),
            ),
          );
        },
      ),
    );
  }
}

class Room {
  final String number;
  final String status;
  final String occupant;

  Room({required this.number, required this.status, required this.occupant});
}
