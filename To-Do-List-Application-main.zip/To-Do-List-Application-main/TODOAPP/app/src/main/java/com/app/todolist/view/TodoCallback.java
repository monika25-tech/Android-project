 

package com.app.todolist.view;

import com.app.todolist.model.BaseTodo;


public interface TodoCallback {
    void finish(BaseTodo b);
}
