package com.example.kioskapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView serviceDescriptionTextView;
    private Button service1Button;
    private Button service2Button;
    private Button service3Button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        serviceDescriptionTextView = findViewById(R.id.serviceDescriptionTextView);
        service1Button = findViewById(R.id.service1Button);
        service2Button = findViewById(R.id.service2Button);
        service3Button = findViewById(R.id.service3Button);

        // Set click listeners
        service1Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayServiceDescription("Service 1 Description: This service provides ...");
            }
        });

        service2Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayServiceDescription("Service 2 Description: This service offers ...");
            }
        });

        service3Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayServiceDescription("Service 3 Description: This service includes ...");
            }
        });
    }

    private void displayServiceDescription(String description) {
        serviceDescriptionTextView.setText(description);
    }
}
