package com.example.onlinevotingapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
