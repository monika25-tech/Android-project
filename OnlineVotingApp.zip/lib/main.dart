import 'package:flutter/material.dart';

void main() {
  runApp(OnlineVotingApp());
}

class OnlineVotingApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  void _login() {
    // Add login logic here
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => VotePage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Online Voting App'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            TextField(
              controller: _usernameController,
              decoration: InputDecoration(labelText: 'Username'),
            ),
            TextField(
              controller: _passwordController,
              decoration: InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _login,
              child: Text('Login'),
            ),
          ],
        ),
      ),
    );
  }
}

class VotePage extends StatelessWidget {
  final List<String> candidates = ['Candidate 1', 'Candidate 2', 'Candidate 3'];

  void _submitVote(String candidate) {
    // Add vote submission logic here
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Vote'),
      ),
      body: ListView.builder(
        itemCount: candidates.length,
        itemBuilder: (context, index) {
          final candidate = candidates[index];
          return Card(
            child: ListTile(
              title: Text(candidate),
              trailing: ElevatedButton(
                onPressed: () {
                  _submitVote(candidate);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Vote submitted for $candidate')),
                  );
                },
                child: Text('Vote'),
              ),
            ),
          );
        },
      ),
    );
  }
}
